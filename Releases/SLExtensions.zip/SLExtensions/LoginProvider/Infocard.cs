﻿namespace SLExtensions.LoginProvider
{
    using System;
    using System.Collections.Generic;
    using System.Net;
    using System.Text;
    using System.Text.RegularExpressions;
    using System.Windows;
    using System.Windows.Browser;
    using System.Windows.Controls;
    using System.Windows.Documents;
    using System.Windows.Ink;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Animation;
    using System.Windows.Shapes;

    public class Infocard
    {
        #region Fields

        public const string FieldsCountry = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/country";
        public const string FieldsDateOfBirth = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/dateofbirth";
        public const string FieldsEmail = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress";
        public const string FieldsGender = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender";

        /* claims */
        public const string FieldsGivenName = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname";
        public const string FieldsHomePhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/homephone";
        public const string FieldsLocality = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/locality";
        public const string FieldsMobilePhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/mobilephone";
        public const string FieldsOtherPhone = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/otherphone";
        public const string FieldsPPID = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/privatepersonalidentifier";
        public const string FieldsPostalCode = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/postalcode";
        public const string FieldsStateOrProvince = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/stateorprovince";
        public const string FieldsStreetAddress = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/streetaddress";
        public const string FieldsSurname = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname";
        public const string FieldsWebpage = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/webpage";
        public const string SAML10 = "urn:oasis:names:tc:SAML:1.0:assertion";
        public const string SAML11 = "http://docs.oasis-open.org/wss/oasis-wss-saml-token-profile-1.1#SAMLV1.1";

        private const string detectInfoCardJs = @"{
        function AreCardsSupported()
        {
          // not IE (any version)
          if( navigator.mimeTypes && navigator.mimeTypes.length)  {
        // check to see if there is a mimeType handler.
        x = navigator.mimeTypes['application/x-informationcard'];
        if (x && x.enabledPlugin)
        {
          var res = (this._areCardsSupported = true);
          return res;
        }

        // check for the IdentitySelector event handler is there.
        var event = document.createEvent('Events');
        event.initEvent('IdentitySelectorAvailable', true, true);
        top.dispatchEvent(event);

        if( top.IdentitySelectorAvailable == true)
        {
            return true;
        }
          }
        return false;
        };
        AreCardsSupported()}";

        private static bool? areCardSupported = null;
        private static Regex regExIE = new Regex(@"MSIE ([0-9]{1,}[\.0-9]{0,})");

        #endregion Fields

        #region Constructors

        public Infocard()
        {
            this.TokenType = SAML11;
            RequiredClaims = new List<string>();
            OptionalClaims = new List<string>();
            PrivacyUrl = new Uri("http://www.ucaya.com/openidpolicy.html");
            PrivacyVersion = "1.0";
            RequiredClaims.Add(FieldsPPID);
        }

        #endregion Constructors

        #region Events

        public event EventHandler AuthenticationFailed;

        #endregion Events

        #region Properties

        public static bool IsInfocardSupported
        {
            get
            {
                if (Application.Current == null || Application.Current.RootVisual == null || System.ComponentModel.DesignerProperties.GetIsInDesignMode(Application.Current.RootVisual))
                    return true;

                if (areCardSupported == null)
                {

                    if (HtmlPage.BrowserInformation.Name == "Microsoft Internet Explorer")
                    {
                        Match m = regExIE.Match(HtmlPage.BrowserInformation.UserAgent);
                        if (m.Success && m.Groups.Count > 0 && double.Parse(m.Groups[1].Value, System.Globalization.CultureInfo.InvariantCulture) >= 6)
                        {
                            HtmlElement embed = HtmlPage.Document.CreateElement("object");
                            embed.SetAttribute("type", "application/x-informationcard");
                            areCardSupported = embed.GetProperty("issuerPolicy") != null && (embed.GetProperty("isInstalled") as bool?).GetValueOrDefault();
                            return areCardSupported.Value;
                        }
                    }

                    areCardSupported = (HtmlPage.Window.Eval(detectInfoCardJs) as bool?).GetValueOrDefault();
                }
                return areCardSupported.HasValue ? areCardSupported.Value : false;
            }
        }

        public string Issuer
        {
            get; set;
        }

        public IList<string> OptionalClaims
        {
            get; private set;
        }

        public Uri PrivacyUrl
        {
            get; set;
        }

        public string PrivacyVersion
        {
            get; set;
        }

        public IList<string> RequiredClaims
        {
            get; private set;
        }

        public string TokenType
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        public HtmlElement GetInformationCard()
        {
            HtmlElement obj = HtmlPage.Document.CreateElement("object");

            StringBuilder sb = new StringBuilder();
            // add all parameters first
            foreach (var item in RequiredClaims)
            {
                sb.Append(item);
                sb.Append(" ");
            }

            addObjectParameter(obj, "requiredClaims", sb.ToString());

            if (!string.IsNullOrEmpty(TokenType))
                addObjectParameter(obj, "tokenType", TokenType);

            if (OptionalClaims.Count > 0)
            {
                sb = new StringBuilder();
                // add all parameters first
                foreach (var item in OptionalClaims)
                {
                    sb.Append(item);
                    sb.Append(" ");
                }

                addObjectParameter(obj, "optionalClaims", sb.ToString());
            }

            if (!string.IsNullOrEmpty(this.PrivacyVersion) && PrivacyUrl != null)
            {
                addObjectParameter(obj, "privacyUrl", PrivacyUrl.ToString());
                addObjectParameter(obj, "privacyVersion", PrivacyVersion);
            }

            if (!string.IsNullOrEmpty(Issuer))
                addObjectParameter(obj, "Issuer", Issuer);

            obj.SetAttribute("type", "application/x-informationcard");
            HtmlPage.Document.Body.AppendChild(obj);
            return obj;
        }

        public string GetToken()
        {
            var xmltkn = GetInformationCard();

            return xmltkn.GetProperty("value") as string ?? "";
        }

        protected virtual void OnAuthenticationFailed()
        {
            if (AuthenticationFailed != null)
            {
                AuthenticationFailed(this, EventArgs.Empty);
            }
        }

        private static void addObjectParameter(HtmlElement element, string name, string value)
        {
            var p = HtmlPage.Document.CreateElement("param");
            p.SetAttribute("name", name);
            p.SetAttribute("value", value);
            element.AppendChild(p);
        }

        #endregion Methods

        #region Other

        //public event EventHandler<InfocardEventArgs> Check;
        //protected virtual void OnCheck(InfocardEventArgs e)
        //{
        //    if (Check != null)
        //    {
        //        Check(this, e);
        //    }
        //}
        //public void SignInWithCard()
        //{
        //    string card = GetToken();
        //    if (card.StartsWith("<"))
        //    {
        //        //got a card. let's send it in.
        //        //var f=BrowserUtility.AddNewForm( target ? target : window.location.href );
        //        //BrowserUtility.AddField( f , "action" , action ? action : "SignIn");
        //        //BrowserUtility.AddField( f , "xmltoken" , card );
        //        //BrowserUtility.AddField( f , "sourcepage" , window.location.href);
        //        //BrowserUtility.AddField( f , "rememberUser" , rememberUser ? rememberUser : false);
        //        //if( extraFieldsToSubmit )
        //        //    for(each in extraFieldsToSubmit)
        //        //        BrowserUtility.AddField( f , each, extraFieldsToSubmit[each] );
        //        //f.submit();
        //        try
        //        {
        //            OnCheck(new InfocardEventArgs(card));
        //        }
        //        catch
        //        {
        //            OnAuthenticationFailed();
        //        }
        //    }
        //    else
        //        OnAuthenticationFailed();
        //    //           else {
        //    //    //error, let's go troubleshooting.
        //    //    //want to call a function?
        //    //    if( typeof(trouble) == "function" );
        //    //        return trouble( card );
        //    //    // post to the error page
        //    //    var f=BrowserUtility.AddNewForm(  trouble ? trouble : window.location.href );
        //    //    BrowserUtility.AddField( f , "action" , "troubleshoot");
        //    //    BrowserUtility.AddField( f , "errorvalue" , card );
        //    //    BrowserUtility.AddField( f , "sourcepage" , window.location.href);
        //    //    f.submit();
        //    //}
        //}
        //    SignInWithCard :function(target,action,trouble,rememberUser, extraFieldsToSubmit ) {
        //    eval('debugger');
        //        /// <summary>
        //        /// Gets the token, and forwards the user to the actionable page
        //        /// </summary>
        //        ///
        //        /// <param name="target">the URL to post the token to.</param>
        //        /// <param name="action">an action message sent to the destination page.</param>
        //        /// <param name="trouble">either a URL or a javascript function to call if the get token fails.</param>
        //        /// <param name="rememberUser">a helper value to tell the action page to 'remember me'</param>
        //        with( InformationCard ) {
        //            var card = GetToken();
        //            if( (""+card).charAt(0) == '<' )
        //            {
        //                //got a card. let's send it in.
        //                var f=BrowserUtility.AddNewForm( target ? target : window.location.href );
        //                BrowserUtility.AddField( f , "action" , action ? action : "SignIn");
        //                BrowserUtility.AddField( f , "xmltoken" , card );
        //                BrowserUtility.AddField( f , "sourcepage" , window.location.href);
        //                BrowserUtility.AddField( f , "rememberUser" , rememberUser ? rememberUser : false);
        //                if( extraFieldsToSubmit )
        //                    for(each in extraFieldsToSubmit)
        //                        BrowserUtility.AddField( f , each, extraFieldsToSubmit[each] );
        //                f.submit();
        //            } else {
        //                //error, let's go troubleshooting.
        //                //want to call a function?
        //                if( typeof(trouble) == "function" );
        //                    return trouble( card );
        //                // post to the error page
        //                var f=BrowserUtility.AddNewForm(  trouble ? trouble : window.location.href );
        //                BrowserUtility.AddField( f , "action" , "troubleshoot");
        //                BrowserUtility.AddField( f , "errorvalue" , card );
        //                BrowserUtility.AddField( f , "sourcepage" , window.location.href);
        //                f.submit();
        //            }
        //        }
        //    }
        //}

        #endregion Other
    }
}