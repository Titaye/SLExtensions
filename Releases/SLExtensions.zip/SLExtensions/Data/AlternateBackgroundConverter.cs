﻿namespace SLExtensions.Data
{
    using System;
    using System.Net;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Data;
    using System.Windows.Documents;
    using System.Windows.Ink;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Animation;
    using System.Windows.Shapes;

    public class AlternateBackgroundConverter : IValueConverter
    {
        #region Fields

        SolidColorBrush brush1;
        SolidColorBrush brush2;
        bool flag = false;

        #endregion Fields

        #region Methods

        public object Convert(object value,
            Type targetType,
            object parameter,
            System.Globalization.CultureInfo culture)
        {
            AlternateBackgroundConverterParameter param = (AlternateBackgroundConverterParameter)parameter;
            flag = !flag;
            brush1 = new SolidColorBrush(param.Color1);
            brush2 = new SolidColorBrush(param.Color2);

            return flag ? brush1 : brush2;
        }

        public object ConvertBack(object value,
            Type targetType,
            object parameter,
            System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion Methods
    }
}