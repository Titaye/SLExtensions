﻿namespace SLExtensions.Globalization
{
    using System;
    using System.Net;
    using System.Resources;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Documents;
    using System.Windows.Ink;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Animation;
    using System.Windows.Shapes;

    public static class Localizer
    {
        #region Fields

        // Using a DependencyProperty as the backing store for Text.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ContentKeyProperty = 
            DependencyProperty.RegisterAttached("ContentKey", typeof(string), typeof(Localizer), new PropertyMetadata(OnPropertyChanged));

        // Using a DependencyProperty as the backing store for ResourceManager.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ResourceManagerProperty = 
            DependencyProperty.RegisterAttached("ResourceManager", typeof(ResourceManager), typeof(Localizer), new PropertyMetadata(OnPropertyChanged));

        // Using a DependencyProperty as the backing store for Text.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TextKeyProperty = 
            DependencyProperty.RegisterAttached("TextKey", typeof(string), typeof(Localizer), new PropertyMetadata(OnPropertyChanged));

        // Using a DependencyProperty as the backing store for Tooltip.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TooltipKeyProperty = 
            DependencyProperty.RegisterAttached("TooltipKey", typeof(string), typeof(Localizer), new PropertyMetadata(OnPropertyChanged));

        #endregion Fields

        #region Properties

        public static ResourceManager DefaultResourceManager
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        public static string GetContentKey(DependencyObject obj)
        {
            return (string)obj.GetValue(ContentKeyProperty);
        }

        public static ResourceManager GetResourceManager(DependencyObject obj)
        {
            return (ResourceManager)obj.GetValue(ResourceManagerProperty);
        }

        public static string GetTextKey(DependencyObject obj)
        {
            return (string)obj.GetValue(TextKeyProperty);
        }

        public static string GetTooltipKey(DependencyObject obj)
        {
            return (string)obj.GetValue(TooltipKeyProperty);
        }

        public static void SetContentKey(DependencyObject obj, string value)
        {
            obj.SetValue(ContentKeyProperty, value);
        }

        public static void SetResourceManager(DependencyObject obj, ResourceManager value)
        {
            obj.SetValue(ResourceManagerProperty, value);
        }

        public static void SetTextKey(DependencyObject obj, string value)
        {
            obj.SetValue(TextKeyProperty, value);
        }

        public static void SetTooltipKey(DependencyObject obj, string value)
        {
            obj.SetValue(TooltipKeyProperty, value);
        }

        private static void Localize(DependencyObject d)
        {
            ResourceManager rm = GetResourceManager(d);

            if (rm == null)
            {
                if(Application.Current.RootVisual != null)
                    rm = GetResourceManager(Application.Current.RootVisual);
            }

            if (rm == null)
            {
                rm = DefaultResourceManager;
            }

            if(rm == null)
            {
                return;
            }

            string textKey = GetTextKey(d);
            if (textKey != null)
            {
                TextBlock tb = d as TextBlock;
                if (tb != null)
                {
                    tb.Text = rm.GetString(textKey);
                }
            }

            string tooltipKey = GetTooltipKey(d);
            if (tooltipKey != null)
            {
                ToolTipService.SetToolTip(d, rm.GetString(tooltipKey));
            }

            string contentKey = GetContentKey(d);
            if (contentKey != null)
            {
                ContentControl cc = d as ContentControl;
                if (cc != null)
                {
                    cc.Content = rm.GetString(contentKey);
                }
            }
        }

        private static void OnPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            Localize(d);
        }

        #endregion Methods
    }
}