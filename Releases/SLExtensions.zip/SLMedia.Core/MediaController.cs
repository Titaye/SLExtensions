﻿namespace SLMedia.Core
{
    using System;
    using System.ComponentModel;
    using System.Linq;
    using System.Net;
    using System.Windows;
    using System.Windows.Browser;
    using System.Windows.Controls;
    using System.Windows.Controls.Primitives;
    using System.Windows.Documents;
    using System.Windows.Ink;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Animation;
    using System.Windows.Media.Imaging;
    using System.Windows.Shapes;
    using System.Windows.Threading;

    using SLExtensions;
    using SLExtensions.Collections.ObjectModel;
    using System.Collections.Generic;

    public abstract class MediaController : NotifyingObject, IDisposable
    {
        #region Fields

        public const string CurrentItemPropertyName = "CurrentItem";
        public const string DownloadProgressPropertyName = "DownloadProgress";
        public const string DurationPropertyName = "Duration";
        public const string IsChainingPropertyName = "IsChaining";
        public const string IsMutedPropertyName = "IsMuted";
        public const string IsNextEnabledPropertyName = "IsNextEnabled";
        public const string IsPreviousEnabledPropertyName = "IsPreviousEnabled";
        public const string NextElementPropertyName = "NextElement";
        public const string PauseOnClickPropertyName = "PauseOnClick";
        public const string PlaylistPropertyName = "Playlist";
        public const string PlaylistSourcePropertyName = "PlaylistSource";
        public const string PositionPropertyName = "Position";

        //public const string PositionPropertyName = "Position";
        //public const string PositionTimePropertyName = "PositionTime";
        public const string PreviousElementPropertyName = "PreviousElement";
        public const string LastSelectedItemPropertyName = "LastSelectedItem";
        public const string SelectedIndexPropertyName = "SelectedIndex";
        public const string VolumePropertyName = "Volume";

        private IMediaItem currentItem;
        private double downloadProgress;
        private Duration duration;
        private Popup fullscreenPopup = null;
        private bool isChaining;
        private bool isDownloading;
        private bool isFullscreen;
        private bool isMuted = false;
        private bool isNextEnabled;
        private bool isPlaying;
        private bool isPopupFullscreen;
        private bool isPreviousEnabled;
        private bool jsregistered = false;
        private MediaBinderSubscription mediaBinderSubscription;
        private string mediaName;
        private FrameworkElement nextElement;
        private bool pauseOnClick = true;
        private PlayStates playState;
        private System.Collections.ObjectModel.ObservableCollection<IMediaItem> playlist;
        private IPlaylistSource playlistSource;
        private TimeSpan position;

        //private TimeSpan positionTime;
        private FrameworkElement previousElement;
        private IMediaItem lastSelectedItem;
        private DispatcherTimer refreshPositionTimer;
        private int? selectedIndex;
        private Control stateControl;
        private double volume = 0.5;

        #endregion Fields

        #region Constructors

        public MediaController()
        {
            Playlist = new System.Collections.ObjectModel.ObservableCollection<IMediaItem>();
            refreshPositionTimer = new DispatcherTimer();
            refreshPositionTimer.Interval = TimeSpan.FromMilliseconds(100);
            refreshPositionTimer.Tick += new EventHandler(refreshPositionTimer_Tick);

            Application.Current.Host.Content.FullScreenChanged += new EventHandler(Content_FullScreenChanged);
        }

        #endregion Constructors

        #region Events

        [ScriptableMemberAttribute]
        public event EventHandler CurrentItemChanged;

        #endregion Events

        #region Properties

        [ScriptableMemberAttribute]
        public IMediaItem CurrentItem
        {
            get { return currentItem; }
            set
            {
                if (currentItem != value)
                {
                    LastSelectedItem = currentItem;
                    currentItem = value;
                    OnPropertyChanged(CurrentItemPropertyName);
                    OnCurrentItemChanged();
                }
            }
        }

        [ScriptableMemberAttribute]
        public double DownloadProgress
        {
            get { return downloadProgress; }
            set
            {
                if (downloadProgress != value)
                {
                    downloadProgress = value;
                    OnPropertyChanged(DownloadProgressPropertyName);
                }
            }
        }

        [ScriptableMemberAttribute]
        public Duration Duration
        {
            get { return duration; }
            set
            {
                if (duration != value)
                {
                    duration = value;
                    OnPropertyChanged(DurationPropertyName);
                    OnDurationChanged();
                }
            }
        }

        [ScriptableMemberAttribute]
        public bool IsChaining
        {
            get { return isChaining; }
            set
            {
                if (isChaining != value)
                {
                    isChaining = value;
                    OnPropertyChanged(IsChainingPropertyName);
                }
            }
        }

        [ScriptableMemberAttribute]
        public bool IsDownloading
        {
            get { return isDownloading; }
            set
            {
                if (isDownloading != value)
                {
                    isDownloading = value;
                    OnPropertyChanged("IsDownloading");
                }
                RefreshControlState();
            }
        }

        [ScriptableMemberAttribute]
        public bool IsFullscreen
        {
            get { return isFullscreen; }
            set
            {
                if (isFullscreen != value)
                {
                    isFullscreen = value;
                    OnPropertyChanged("IsFullscreen");

                    Application.Current.Host.Content.IsFullScreen = value;
                    RefreshControlState();
                    OnFullscreenChanged();
                }
            }
        }

        protected virtual void OnFullscreenChanged()
        {
            
        }

        [ScriptableMemberAttribute]
        public bool IsMuted
        {
            get { return isMuted; }
            set
            {
                if (isMuted != value)
                {
                    isMuted = value;
                    OnPropertyChanged(IsMutedPropertyName);
                    RefreshControlState();
                }
            }
        }

        [ScriptableMemberAttribute]
        public bool IsNextEnabled
        {
            get { return isNextEnabled; }
            set
            {
                if (isNextEnabled != value)
                {
                    isNextEnabled = value;
                    OnPropertyChanged(IsNextEnabledPropertyName);
                }
            }
        }

        [ScriptableMemberAttribute]
        public bool IsPlaying
        {
            get { return isPlaying; }
            set
            {
                if (isPlaying != value)
                {
                    isPlaying = value;
                    OnPropertyChanged("IsPlaying");
                    IsPlayingChanged();
                    RefreshControlState();
                }
            }
        }

        [ScriptableMemberAttribute]
        public bool IsPopupFullscreen
        {
            get { return isPopupFullscreen; }
            set
            {
                if (isPopupFullscreen != value)
                {
                    isPopupFullscreen = value;
                    OnPropertyChanged("IsPopupFullscreen");

                    if (value)
                    {
                        IsFullscreen = true;
                        SwitchFullscreenPopup();
                    }
                    else
                    {
                        IsFullscreen = false;
                    }
                    RefreshControlState();
                }
            }
        }

        [ScriptableMemberAttribute]
        public bool IsPreviousEnabled
        {
            get { return isPreviousEnabled; }
            set
            {
                if (isPreviousEnabled != value)
                {
                    isPreviousEnabled = value;
                    OnPropertyChanged(IsPreviousEnabledPropertyName);
                }
            }
        }

        public string MediaName
        {
            get { return mediaName; }
            set
            {
                if (mediaName != value)
                {
                    mediaName = value;
                    OnPropertyChanged("MediaName");
                    mediaBinderSubscription = MediaBinder.GetSubscription(value as string);
                    mediaBinderSubscription.MediaController = this;
                }
            }
        }

        [ScriptableMemberAttribute]
        public FrameworkElement NextElement
        {
            get { return nextElement; }
            set
            {
                if (nextElement != value)
                {
                    if (this.nextElement != null)
                    {
                        ButtonBase nextButton = this.nextElement as ButtonBase;
                        if (nextButton != null)
                            nextButton.Click -= new RoutedEventHandler(nextButton_Click);
                        else
                            nextButton.MouseLeftButtonDown -= new MouseButtonEventHandler(nextButton_MouseLeftButtonDown);
                    }

                    nextElement = value;
                    OnPropertyChanged(NextElementPropertyName);

                    if (this.nextElement != null)
                    {
                        ButtonBase nextButton = this.nextElement as ButtonBase;
                        if (nextButton != null)
                            nextButton.Click += new RoutedEventHandler(nextButton_Click);
                        else
                            nextButton.MouseLeftButtonDown += new MouseButtonEventHandler(nextButton_MouseLeftButtonDown);
                    }
                }
            }
        }

        [ScriptableMemberAttribute]
        public bool PauseOnClick
        {
            get { return pauseOnClick; }
            set
            {
                if (pauseOnClick != value)
                {
                    pauseOnClick = value;
                    OnPropertyChanged(PauseOnClickPropertyName);
                }
            }
        }

        [ScriptableMemberAttribute]
        public PlayStates PlayState
        {
            get { return playState; }
            set
            {
                if (playState != value)
                {
                    playState = value;
                    IsPlaying = PlayState == PlayStates.Playing;
                    OnPropertyChanged("PlayState");
                }
                RefreshControlState();
            }
        }

        [ScriptableMemberAttribute]
        public System.Collections.ObjectModel.ObservableCollection<IMediaItem> Playlist
        {
            get { return playlist; }
            set
            {
                if (playlist != value)
                {
                    playlist = value;
                    OnPropertyChanged(PlaylistPropertyName);
                    RefreshNexPrevious();
                }
            }
        }

        [ScriptableMemberAttribute]
        public IPlaylistSource PlaylistSource
        {
            get { return playlistSource; }
            set
            {
                if (playlistSource != value)
                {
                    if (playlistSource != null)
                    {
                        UnbindPlaylistSource();
                    }

                    playlistSource = value;

                    if (playlistSource != null)
                    {
                        BindPlaylistSource();
                    }

                    OnPropertyChanged(PlaylistSourcePropertyName);
                }
            }
        }

        [ScriptableMemberAttribute]
        public TimeSpan Position
        {
            get { return position; }
            set
            {
                if (position != value)
                {
                    position = value;
                    OnPropertyChanged(PositionPropertyName);
                    OnPositionChanged();
                }
            }
        }

        //public TimeSpan PositionTime
        //{
        //    get { return positionTime; }
        //    set
        //    {
        //        if (positionTime != value)
        //        {
        //            positionTime = value;
        //            OnPropertyChanged(PositionTimePropertyName);
        //        }
        //    }
        //}
        [ScriptableMemberAttribute]
        public FrameworkElement PreviousElement
        {
            get { return previousElement; }
            set
            {
                if (previousElement != value)
                {
                    if (this.previousElement != null)
                    {
                        ButtonBase previousButton = this.previousElement as ButtonBase;
                        if (previousButton != null)
                            previousButton.Click -= new RoutedEventHandler(previousButton_Click);
                        else
                            previousButton.MouseLeftButtonDown -= new MouseButtonEventHandler(previousButton_MouseLeftButtonDown);
                    }

                    previousElement = value;
                    OnPropertyChanged(PreviousElementPropertyName);

                    if (this.previousElement != null)
                    {
                        ButtonBase previousButton = this.previousElement as ButtonBase;
                        if (previousButton != null)
                            previousButton.Click += new RoutedEventHandler(previousButton_Click);
                        else
                            previousButton.MouseLeftButtonDown += new MouseButtonEventHandler(previousButton_MouseLeftButtonDown);
                    }
                }
            }
        }

        [ScriptableMemberAttribute]
        public IMediaItem LastSelectedItem
        {
            get { return lastSelectedItem; }
            set
            {
                if (lastSelectedItem != value)
                {
                    lastSelectedItem = value;
                    OnPropertyChanged(LastSelectedItemPropertyName);
                }
            }
        }

        public int SelectedIndex
        {
            get { return selectedIndex.GetValueOrDefault(-1); }
            set
            {
                if (Playlist == null || value < 0
                    || value >= Playlist.Count)
                {
                    value = -1;
                }

                if (selectedIndex != value)
                {
                    selectedIndex = value;
                    OnPropertyChanged(SelectedIndexPropertyName);
                }
            }
        }

        [ScriptableMemberAttribute]
        public Control StateControl
        {
            get { return stateControl; }
            set
            {
                if (stateControl != value)
                {
                    stateControl = value;
                    OnPropertyChanged("StateControl");
                    stateControl.Loaded += new RoutedEventHandler(stateControl_Loaded);
                }
            }
        }

        [ScriptableMemberAttribute]
        public double Volume
        {
            get { return volume; }
            set
            {
                if (volume != value)
                {
                    volume = value;
                    OnPropertyChanged(VolumePropertyName);
                }
            }
        }

        protected Popup FullscreenPopup
        {
            get { return fullscreenPopup; }
        }

        #endregion Properties

        #region Methods

        [ScriptableMember]
        public void AddItem(MediaItem item)
        {
            Playlist.Add(item);
        }

        [ScriptableMemberAttribute]
        public Category CreateCategory()
        {
            return new Category();
        }

        [ScriptableMemberAttribute]
        public MediaItem CreateMediaItem()
        {
            return new MediaItem() { Type = MediaItemType.Video };
        }

        public virtual void Dispose()
        {
            Playlist = null;
            PlaylistSource = null;
        }

        [ScriptableMember]
        public void InsertItem(int index, MediaItem item)
        {
            Playlist.Insert(index, item);
        }

        [ScriptableMemberAttribute]
        public virtual void Next()
        {
            if (Playlist == null)
                return;

            CurrentItemIndex = Math.Min(Playlist.Count - 1, CurrentItemIndex + 1);
            //IMediaItem[] playlist = Playlist.ToArray();
            //if (playlist.Length == 0)
            //    return;

            //if (CurrentItem == null)
            //    CurrentItem = playlist[0];
            //else
            //{
            //    int idx = playlist.IndexOf(CurrentItem);
            //    if (idx == playlist.Length - 1)
            //        return;

            //    CurrentItem = playlist[idx + 1];
            //}
        }

        [ScriptableMember]
        public void PlayIndex(int index)
        {
            if (Playlist == null)
                return;

            if (index >= 0 && index < Playlist.Count)
                CurrentItem = Playlist[index];
        }

        [ScriptableMember]
        public void PlayItem(MediaItem item)
        {
            CurrentItem = item;
        }

        [ScriptableMemberAttribute]
        public virtual void Previous()
        {
            if (Playlist == null)
                return;

            CurrentItemIndex = Math.Max(0, CurrentItemIndex - 1);
            
            //IMediaItem[] playlist = Playlist.ToArray();
            //if (playlist.Length == 0)
            //    return;

            //if (CurrentItem == null)
            //    CurrentItem = playlist[0];
            //else
            //{
            //    int idx = playlist.IndexOf(CurrentItem);
            //    if (idx == 0)
            //        return;

            //    CurrentItem = playlist[idx - 1];
            //}
        }

        [ScriptableMember]
        public void RevoveItem(MediaItem item)
        {
            Playlist.Remove(item);
        }

        [ScriptableMember]
        public void RevoveItemAt(int index)
        {
            Playlist.RemoveAt(index);
        }

        protected abstract FrameworkElement CreateFullscreenPopupContent();

        protected virtual void IsPlayingChanged()
        {
            if (IsPlaying)
                refreshPositionTimer.Start();
            else
                refreshPositionTimer.Stop();
        }

        protected virtual void OnCurrentItemChanged()
        {
            IsDownloading = false;
            DownloadProgress = 1;

            RefreshNexPrevious();

            if (CurrentItemChanged != null)
            {
                CurrentItemChanged(this, EventArgs.Empty);
            }
        }

        protected virtual void OnDurationChanged()
        {
        }

        protected virtual void OnPositionChanged()
        {
        }

        private PlayStates? lastPlayState = null;
        private bool? lastDownloadingState = null;
        private bool? lastFullStreenState = null;

        protected virtual void RefreshControlState()
        {
            if (StateControl == null)
                return;

            if (lastPlayState != PlayState)
            {
                lastPlayState = PlayState;
                try
                {
                    VisualStateManager.GoToState(StateControl, PlayState.ToString(), true);
                }
                catch
                {
                }
            }

            if (lastDownloadingState != IsDownloading)
            {
                lastDownloadingState = IsDownloading;
                VisualStateManager.GoToState(StateControl, IsDownloading ? "Downloading" : "DownloadReady", true);
            }

            if (lastFullStreenState != Application.Current.Host.Content.IsFullScreen)
            {
                lastFullStreenState = Application.Current.Host.Content.IsFullScreen;
                VisualStateManager.GoToState(StateControl, Application.Current.Host.Content.IsFullScreen ? "Fullscreen" : "Smallscreen", true);
            }
        }

        protected virtual void RefreshPosition()
        {
        }

        protected virtual void SwitchPauseOnClick()
        {
            if (IsPlaying)
            {
                IsPlaying = false;
            }
            else
            {
                IsPlaying = true;
            }
        }

        private void BindPlaylistSource()
        {
            INotifyPropertyChanged playlistSource = PlaylistSource as INotifyPropertyChanged;
            if (playlistSource != null)
            {
                playlistSource.PropertyChanged += new PropertyChangedEventHandler(playlistSource_PropertyChanged);
            }
        }

        void Content_FullScreenChanged(object sender, EventArgs e)
        {
            if (!Application.Current.Host.Content.IsFullScreen)
            {
                if (fullscreenPopup != null)
                {
                    fullscreenPopup.IsOpen = false;
                    fullscreenPopup = null;
                }

                IsFullscreen = false;
                IsPopupFullscreen = false;
            }
            else
            {
                if (fullscreenPopup != null)
                {
                    Grid grid = fullscreenPopup.Child as Grid;
                    grid.Width = Application.Current.Host.Content.ActualWidth;
                    grid.Height = Application.Current.Host.Content.ActualHeight;
                }

                IsFullscreen = true;
            }
        }

        private void RefreshNexPrevious()
        {
            bool nextIsEnabled = false;
            bool prevIsEnabled = false;

            if (Playlist == null)
            {
                nextIsEnabled = false;
                prevIsEnabled = false;
            }
            else
            {
                IMediaItem[] playlist = Playlist.ToArray();
                if (CurrentItem == null)
                {
                    nextIsEnabled = true;
                }
                else
                {
                    int idx = Array.IndexOf(playlist, CurrentItem);
                    if (idx == -1)
                    {
                        nextIsEnabled = true;
                    }
                    else
                    {
                        prevIsEnabled = idx != 0;
                        nextIsEnabled = idx != playlist.Length - 1;
                    }
                }
            }

            IsPreviousEnabled = prevIsEnabled;
            IsNextEnabled = nextIsEnabled;
        }

        private void SwitchFullscreenPopup()
        {
            if (fullscreenPopup == null)
            {
                fullscreenPopup = new Popup();
                Grid grid = new Grid();
                grid.Background = new SolidColorBrush(Colors.Black);

                FrameworkElement child = CreateFullscreenPopupContent();
                grid.Children.Add(child);
                child.MouseLeftButtonDown += new MouseButtonEventHandler(fullscreenPopup_MouseLeftButtonDown);

                fullscreenPopup.Child = grid;
                fullscreenPopup.IsOpen = true;

            }
        }

        private void UnbindPlaylistSource()
        {
            INotifyPropertyChanged playlistSource = PlaylistSource as INotifyPropertyChanged;
            if (playlistSource != null)
            {
                playlistSource.PropertyChanged -= new PropertyChangedEventHandler(playlistSource_PropertyChanged);
            }
        }

        void fullscreenPopup_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            SwitchPauseOnClick();
        }

        void nextButton_Click(object sender, RoutedEventArgs e)
        {
            Next();
        }

        void nextButton_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Next();
        }

        void playlistSource_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "Playlist")
            {
                Playlist = new ObservableCollection<IMediaItem>(PlaylistSource.Playlist);
            }
        }

        void previousButton_Click(object sender, RoutedEventArgs e)
        {
            Previous();
        }

        void previousButton_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Previous();
        }

        void refreshPositionTimer_Tick(object sender, EventArgs e)
        {
            RefreshPosition();
        }

        void stateControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (!jsregistered && !string.IsNullOrEmpty(MediaName))
            {
                jsregistered = true;
                if(!System.ComponentModel.DesignerProperties.GetIsInDesignMode((DependencyObject) sender))
                {
                    HtmlPage.RegisterScriptableObject(MediaName, this);
                    ScriptObject jsFunction = HtmlPage.Window.GetProperty("mediaControllerLoaded") as ScriptObject;
                    if (jsFunction != null)
                        jsFunction.InvokeSelf(this);
                }
            }
        }

        #endregion Methods

        private IEnumerable<IMediaItem> previousItems;
        public IEnumerable<IMediaItem> PreviousItems
        {
            get { return previousItems; }
            set
            {
                if (previousItems != value)
                {
                    previousItems = value;
                    OnPropertyChanged(PreviousItemsPropertyName);
                }
            }
        }

        public const string PreviousItemsPropertyName = "PreviousItems";

        private IEnumerable<IMediaItem> nextItems;
        public IEnumerable<IMediaItem> NextItems
        {
            get { return nextItems; }
            set
            {
                if (nextItems != value)
                {
                    nextItems = value;
                    OnPropertyChanged(NextItemsPropertyName);
                }
            }
        }

        public const string NextItemsPropertyName = "NextItems";

        private int currentItemIndex = -1;
        public int CurrentItemIndex
        {
            get { return currentItemIndex; }
            set
            {
                if (currentItemIndex != value)
                {
                    currentItemIndex = value;

                    if (Playlist != null && currentItemIndex >= 0 && currentItemIndex < Playlist.Count)
                    {
                        CurrentItem = Playlist[currentItemIndex];
                    }
                    else
                    {
                        currentItemIndex = -1;
                        CurrentItem = null;
                    }

                    if (Playlist != null)
                    {
                        PreviousItems = Playlist.Take(Math.Max(0, currentItemIndex)).ToArray();
                        NextItems = Playlist.Skip(currentItemIndex + 1).ToArray();
                    }
                    else
                    {
                        PreviousItems = null;
                        NextItems = null;
                    }
                    
                    OnPropertyChanged(CurrentItemIndexPropertyName);
                }
            }
        }

        public const string CurrentItemIndexPropertyName = "CurrentItemIndex";



    }
}
