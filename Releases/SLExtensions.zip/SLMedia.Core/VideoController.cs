﻿namespace SLMedia.Core
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Linq;
    using System.Net;
    using System.Windows;
    using System.Windows.Browser;
    using System.Windows.Controls;
    using System.Windows.Documents;
    using System.Windows.Ink;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Animation;
    using System.Windows.Shapes;
    using System.Windows.Threading;

    using SLExtensions;
    using SLExtensions.Collections.ObjectModel;
    using SLExtensions.Diagnostics;

    public class VideoController : MediaController
    {
        #region Fields

        public const string BufferingProgressPropertyName = "BufferingProgress";

        private double bufferingProgress;

        //private void RefreshPosition()
        //{
        //    if (MediaElement != null)
        //    {
        //        if (MediaElement.NaturalDuration.HasTimeSpan && MediaElement.NaturalDuration.TimeSpan.TotalSeconds != 0)
        //        {
        //            Position = (MediaElement.Position.TotalSeconds / MediaElement.NaturalDuration.TimeSpan.TotalSeconds);
        //            PositionTime = MediaElement.NaturalDuration.TimeSpan;
        //        }
        //        else
        //        {
        //            Position = 0;
        //            PositionTime = new TimeSpan();
        //        }
        //    }
        //}
        //private TimeSpan position;
        //public TimeSpan Position
        //{
        //    get { return position; }
        //    set
        //    {
        //        if (position != value)
        //        {
        //            position = value;
        //            OnPropertyChanged(PositionPropertyName);
        //            Debug.WriteLine("Pos " + value);
        //        }
        //    }
        //}
        //public const string PositionPropertyName = "Position";
        private bool inRefreshPosition = false;
        private bool isBuffering;
        private MediaElement mediaElement;

        #endregion Fields

        #region Constructors

        public VideoController()
        {
            //timer = new DispatcherTimer();
            //timer.Interval = TimeSpan.FromMilliseconds(200);
            //timer.Tick += new EventHandler(timer_Tick);
        }

        #endregion Constructors

        #region Properties

        public double BufferingProgress
        {
            get { return bufferingProgress; }
            set
            {
                if (bufferingProgress != value)
                {
                    bufferingProgress = value;
                    OnPropertyChanged(BufferingProgressPropertyName);
                }
            }
        }

        public bool IsBuffering
        {
            get { return isBuffering; }
            set
            {
                if (isBuffering != value)
                {
                    isBuffering = value;
                    OnPropertyChanged("IsBuffering");
                }
            }
        }

        public MediaElement MediaElement
        {
            get { return mediaElement; }
            set
            {
                if (mediaElement != value)
                {
                    if (this.mediaElement != null)
                    {
                        this.mediaElement.CurrentStateChanged -= new RoutedEventHandler(MediaElement_CurrentStateChanged);
                        this.mediaElement.BufferingProgressChanged -= new RoutedEventHandler(mediaElement_BufferingProgressChanged);
                        this.mediaElement.MediaOpened -= new RoutedEventHandler(mediaElement_MediaOpened);
                        this.mediaElement.MediaEnded -= new RoutedEventHandler(mediaElement_MediaEnded);
                        this.mediaElement.MouseLeftButtonDown -= new MouseButtonEventHandler(mediaElement_MouseLeftButtonDown);
                    }

                    this.mediaElement = value;

                    if (this.mediaElement != null)
                    {
                        this.mediaElement.CurrentStateChanged += new RoutedEventHandler(MediaElement_CurrentStateChanged);
                        this.mediaElement.BufferingProgressChanged += new RoutedEventHandler(mediaElement_BufferingProgressChanged);
                        this.mediaElement.MediaOpened += new RoutedEventHandler(mediaElement_MediaOpened);
                        this.mediaElement.MediaEnded += new RoutedEventHandler(mediaElement_MediaEnded);
                        this.mediaElement.MouseLeftButtonDown += new MouseButtonEventHandler(mediaElement_MouseLeftButtonDown);
                    }
                    RefreshStates();
                    OnPropertyChanged("MediaElement");
                }
            }
        }

        #endregion Properties

        #region Methods

        protected override FrameworkElement CreateFullscreenPopupContent()
        {
            Rectangle rect = new Rectangle();

            VideoBrush videobrush = new VideoBrush();
            videobrush.Stretch = Stretch.Uniform;
            videobrush.SetSource(MediaElement);
            rect.Fill = videobrush;
            return rect;
        }

        protected override void IsPlayingChanged()
        {
            base.IsPlayingChanged();

            //if (IsPlaying)
            //    timer.Start();
            //else
            //    timer.Stop();

            if (MediaElement == null)
                return;

            if (IsPlaying == true)
                MediaElement.Play();
            else
                MediaElement.Pause();
        }

        protected override void OnPositionChanged()
        {
            base.OnPositionChanged();

            if (!inRefreshPosition && MediaElement != null)
                MediaElement.Position = Position;
        }

        protected override void RefreshControlState()
        {
            base.RefreshControlState();
            VisualStateManager.GoToState(StateControl, IsBuffering ? "Buffering" : "BufferReady", true);
        }

        //private DispatcherTimer timer;
        //void timer_Tick(object sender, EventArgs e)
        //{
        //    RefreshPosition();
        //}
        protected override void RefreshPosition()
        {
            inRefreshPosition = true;
            try
            {
                base.RefreshPosition();
                if (MediaElement != null)
                    Position = MediaElement.Position;
            }
            finally
            {
                inRefreshPosition = false;
            }
        }

        void MediaElement_CurrentStateChanged(object sender, RoutedEventArgs e)
        {
            RefreshMediaElementState();
        }

        private void RefreshMediaElementState()
        {
            if (MediaElement.CurrentState == MediaElementState.Buffering)
            {
                IsBuffering = true;
            }
            else
            {
                IsBuffering = false;
            }

            switch (MediaElement.CurrentState)
            {
                case MediaElementState.AcquiringLicense:
                    break;
                case MediaElementState.Buffering:
                    break;
                case MediaElementState.Closed:
                    break;
                case MediaElementState.Individualizing:
                    break;
                case MediaElementState.Opening:
                    break;
                case MediaElementState.Paused:
                    PlayState = PlayStates.Paused;
                    break;
                case MediaElementState.Playing:
                    PlayState = PlayStates.Playing;
                    break;
                case MediaElementState.Stopped:
                    PlayState = PlayStates.Stopped;
                    break;
                default:
                    break;
            }

            RefreshControlState();
        }

        private void RefreshStates()
        {
            //RefreshPosition();

            RefreshMediaElementState();
        }

        void mediaElement_BufferingProgressChanged(object sender, RoutedEventArgs e)
        {
            BufferingProgress = MediaElement.BufferingProgress;
        }

        void mediaElement_MediaEnded(object sender, RoutedEventArgs e)
        {
            if (IsChaining)
            {
                Next();
            }
        }

        void mediaElement_MediaOpened(object sender, RoutedEventArgs e)
        {
            //RefreshPosition();
            Duration = MediaElement.NaturalDuration;
        }

        void mediaElement_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            SwitchPauseOnClick();
        }

        #endregion Methods
    }
}
