﻿// <copyright file="Tween.cs" company="Ucaya">
// Distributed under Microsoft Public License (Ms-PL)
// </copyright>
// <author>Thierry Bouquain</author>
namespace SLExtensions.Controls.Tween
{
    using System;
    using System.Net;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Documents;
    using System.Windows.Ink;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Animation;
    using System.Windows.Shapes;

    /// <summary>
    /// Provides the tween attached property.
    /// </summary>
    public static class Tween
    {
        #region Fields

        public static readonly DependencyProperty FromProperty = 
            DependencyProperty.RegisterAttached("From", typeof(double), typeof(Tween), new PropertyMetadata(OnTweenChanged));
        public static readonly DependencyProperty ToProperty = 
            DependencyProperty.RegisterAttached("To", typeof(double), typeof(Tween), new PropertyMetadata(OnTweenChanged));
        public static readonly DependencyProperty TypeProperty = 
            DependencyProperty.RegisterAttached("Type", typeof(EquationType), typeof(Tween), new PropertyMetadata(OnTweenChanged));

        #endregion Fields

        #region Delegates

        private delegate double Equation(params double[] args);

        #endregion Delegates

        #region Methods

        /// <summary>
        /// Gets the tween's starting value.
        /// </summary>
        /// <param name="o">The o.</param>
        /// <returns></returns>
        public static double GetFrom(DependencyObject o)
        {
            return (double)o.GetValue(FromProperty);
        }

        /// <summary>
        /// Gets the tween's ending value.
        /// </summary>
        /// <param name="o">The o.</param>
        /// <returns></returns>
        public static double GetTo(DependencyObject o)
        {
            return (double)o.GetValue(ToProperty);
        }

        /// <summary>
        /// Gets the tween type.
        /// </summary>
        /// <param name="o">The o.</param>
        /// <returns></returns>
        public static EquationType GetType(DependencyObject o)
        {
            return (EquationType)o.GetValue(TypeProperty);
        }

        /// <summary>
        /// Sets the tween's starting value.
        /// </summary>
        /// <param name="o">The o.</param>
        /// <param name="value">The value.</param>
        public static void SetFrom(DependencyObject o, double value)
        {
            o.SetValue(FromProperty, value);
        }

        /// <summary>
        /// Sets the tween's ending value.
        /// </summary>
        /// <param name="o">The o.</param>
        /// <param name="value">The value.</param>
        public static void SetTo(DependencyObject o, double value)
        {
            o.SetValue(ToProperty, value);
        }

        /// <summary>
        /// Sets the tween type.
        /// </summary>
        /// <param name="o">The o.</param>
        /// <param name="value">The value.</param>
        public static void SetType(DependencyObject o, EquationType value)
        {
            o.SetValue(TypeProperty, value);
        }

        private static void OnTweenChanged(DependencyObject o, DependencyPropertyChangedEventArgs e)
        {
            DoubleAnimationUsingKeyFrames animation = o as DoubleAnimationUsingKeyFrames;

            if (animation != null) {
                animation.KeyFrames.Clear();

                EquationType type = GetType(animation);
                double from = GetFrom(animation);
                double to = GetTo(animation);

                Equation equation = (Equation)Delegate.CreateDelegate(typeof(Equation), typeof(Equations).GetMethod(type.ToString()));

                double total = animation.Duration.TimeSpan.TotalMilliseconds;

                for (double i = 0; i < total; i += 50) {
                    LinearDoubleKeyFrame frame = new LinearDoubleKeyFrame();
                    frame.KeyTime = KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(i));
                    frame.Value = equation(i, from, to - from, total);

                    animation.KeyFrames.Add(frame);
                }

                // add final key frame
                LinearDoubleKeyFrame finalFrame = new LinearDoubleKeyFrame();
                finalFrame.KeyTime = KeyTime.FromTimeSpan(TimeSpan.FromMilliseconds(total));
                finalFrame.Value = to;
                animation.KeyFrames.Add(finalFrame);
            }
        }

        #endregion Methods
    }
}