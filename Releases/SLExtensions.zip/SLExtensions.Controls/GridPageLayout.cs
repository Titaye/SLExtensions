﻿namespace SLExtensions.Controls
{
    using System;
    using System.Net;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Documents;
    using System.Windows.Ink;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Animation;
    using System.Windows.Shapes;

    public class GridPageLayout : Panel
    {
        #region Fields

        /// <summary>
        /// ColumnCount depedency property.
        /// </summary>
        public static readonly DependencyProperty ColumnCountProperty = 
            DependencyProperty.Register(
                "ColumnCount",
                typeof(int),
                typeof(GridPageLayout),
                new PropertyMetadata((d, e) => ((GridPageLayout)d).OnColumnCountChanged((int)e.OldValue, (int)e.NewValue)));

        /// <summary>
        /// Orientation depedency property.
        /// </summary>
        public static readonly DependencyProperty OrientationProperty = 
            DependencyProperty.Register(
                "Orientation",
                typeof(Orientation),
                typeof(GridPageLayout),
                new PropertyMetadata((d, e) => ((GridPageLayout)d).OnOrientationChanged((Orientation)e.OldValue, (Orientation)e.NewValue)));

        /// <summary>
        /// PageHeight depedency property.
        /// </summary>
        public static readonly DependencyProperty PageHeightProperty = 
            DependencyProperty.Register(
                "PageHeight",
                typeof(double),
                typeof(GridPageLayout),
                new PropertyMetadata((d, e) => ((GridPageLayout)d).OnPageHeightChanged((double)e.OldValue, (double)e.NewValue)));

        /// <summary>
        /// PageOrientation depedency property.
        /// </summary>
        public static readonly DependencyProperty PageOrientationProperty = 
            DependencyProperty.Register(
                "PageOrientation",
                typeof(Orientation),
                typeof(GridPageLayout),
                new PropertyMetadata((d, e) => ((GridPageLayout)d).OnPageOrientationChanged((Orientation)e.OldValue, (Orientation)e.NewValue)));

        /// <summary>
        /// PageWidth depedency property.
        /// </summary>
        public static readonly DependencyProperty PageWidthProperty = 
            DependencyProperty.Register(
                "PageWidth",
                typeof(double),
                typeof(GridPageLayout),
                new PropertyMetadata((d, e) => ((GridPageLayout)d).OnPageWidthChanged((double)e.OldValue, (double)e.NewValue)));

        /// <summary>
        /// RowCount depedency property.
        /// </summary>
        public static readonly DependencyProperty RowCountProperty = 
            DependencyProperty.Register(
                "RowCount",
                typeof(int),
                typeof(GridPageLayout),
                new PropertyMetadata((d, e) => ((GridPageLayout)d).OnRowCountChanged((int)e.OldValue, (int)e.NewValue)));

        #endregion Fields

        #region Constructors

        public GridPageLayout()
        {
            ColumnCount = 1;
            RowCount = 1;
            Orientation = Orientation.Horizontal;
            PageOrientation = Orientation.Horizontal;
            PageWidth = double.NaN;
            PageHeight = double.NaN;
        }

        #endregion Constructors

        #region Properties

        public int ColumnCount
        {
            get
            {
                return (int)GetValue(ColumnCountProperty);
            }

            set
            {
                SetValue(ColumnCountProperty, value);
            }
        }

        public Orientation Orientation
        {
            get
            {
                return (Orientation)GetValue(OrientationProperty);
            }

            set
            {
                SetValue(OrientationProperty, value);
            }
        }

        public double PageHeight
        {
            get
            {
                return (double)GetValue(PageHeightProperty);
            }

            set
            {
                SetValue(PageHeightProperty, value);
            }
        }

        public Orientation PageOrientation
        {
            get
            {
                return (Orientation)GetValue(PageOrientationProperty);
            }

            set
            {
                SetValue(PageOrientationProperty, value);
            }
        }

        public double PageWidth
        {
            get
            {
                return (double)GetValue(PageWidthProperty);
            }

            set
            {
                SetValue(PageWidthProperty, value);
            }
        }

        public int RowCount
        {
            get
            {
                return (int)GetValue(RowCountProperty);
            }

            set
            {
                SetValue(RowCountProperty, value);
            }
        }

        #endregion Properties

        #region Methods

        protected override Size ArrangeOverride(Size finalSize)
        {
            if (ColumnCount <= 0 || RowCount <= 0)
                return finalSize;

            double pageWidth = PageWidth;
            double pageHeight = PageHeight;

            if (double.IsNaN(pageWidth))
                pageWidth = finalSize.Width;
            if (double.IsNaN(pageHeight))
                pageHeight = finalSize.Height;

            double colWidth = pageWidth / ColumnCount;
            double colHeight = pageHeight / RowCount;

            int pageItemCount = ColumnCount * RowCount;
            int nbPages = (int)Math.Ceiling(((double)Children.Count) / (ColumnCount * RowCount));

            for (int i = 0; i < Children.Count; i++)
            {
                FrameworkElement fe = Children[i] as FrameworkElement;

                int pageIndex = (int)Math.Floor((double)i / pageItemCount);

                int columnIdx = Orientation == Orientation.Horizontal ? (i % pageItemCount) % ColumnCount : (i % pageItemCount) / RowCount;
                int rowIdx = Orientation == Orientation.Horizontal ? (i % pageItemCount) / ColumnCount : (i % pageItemCount) % RowCount;

                double pageOffsetX = PageOrientation == Orientation.Horizontal ? pageWidth * pageIndex : 0;
                double pageOffsetY = PageOrientation == Orientation.Horizontal ? 0 : pageHeight * pageIndex;

                Rect rect = new Rect(pageOffsetX + colWidth * columnIdx, pageOffsetY + colHeight * rowIdx, colWidth, colHeight);
                fe.Arrange(rect);
            }

            if (PageOrientation == Orientation.Horizontal)
                return new Size(nbPages * pageWidth, pageHeight);
            else
                return new Size(pageWidth, nbPages * pageHeight);
        }

        protected override Size MeasureOverride(Size availableSize)
        {
            if (ColumnCount <= 0 || RowCount <= 0)
                return availableSize;

            double pageWidth = PageWidth;
            double pageHeight = PageHeight;

            if (double.IsNaN(pageWidth))
                pageWidth = availableSize.Width;
            if (double.IsNaN(pageHeight))
                pageHeight = availableSize.Height;

            double colWidth = pageWidth / ColumnCount;
            double colHeight = pageHeight / RowCount;

            foreach (var item in Children)
            {
                item.Measure(new Size(colWidth, colHeight));
            }

            int nbPages = (int)Math.Ceiling(((double)Children.Count) / (ColumnCount * RowCount));
            if (PageOrientation == Orientation.Horizontal)
            {
                return new Size(Math.Min(nbPages * pageWidth, availableSize.Width), pageHeight);
            }
            else
                return new Size(pageWidth, Math.Min(nbPages * pageHeight, availableSize.Height));
            //return availableSize;
        }

        /// <summary>
        /// handles the ColumnCountProperty changes.
        /// </summary>
        /// <param name="oldValue">The old value.</param>
        /// <param name="newValue">The new value.</param>
        private void OnColumnCountChanged(int oldValue, int newValue)
        {
            InvalidateMeasure();
        }

        /// <summary>
        /// handles the OrientationProperty changes.
        /// </summary>
        /// <param name="oldValue">The old value.</param>
        /// <param name="newValue">The new value.</param>
        private void OnOrientationChanged(Orientation oldValue, Orientation newValue)
        {
            InvalidateMeasure();
        }

        /// <summary>
        /// handles the PageHeightProperty changes.
        /// </summary>
        /// <param name="oldValue">The old value.</param>
        /// <param name="newValue">The new value.</param>
        private void OnPageHeightChanged(double oldValue, double newValue)
        {
            InvalidateMeasure();
        }

        /// <summary>
        /// handles the PageOrientationProperty changes.
        /// </summary>
        /// <param name="oldValue">The old value.</param>
        /// <param name="newValue">The new value.</param>
        private void OnPageOrientationChanged(Orientation oldValue, Orientation newValue)
        {
            InvalidateMeasure();
        }

        /// <summary>
        /// handles the PageWidthProperty changes.
        /// </summary>
        /// <param name="oldValue">The old value.</param>
        /// <param name="newValue">The new value.</param>
        private void OnPageWidthChanged(double oldValue, double newValue)
        {
            InvalidateMeasure();
        }

        /// <summary>
        /// handles the RowCountProperty changes.
        /// </summary>
        /// <param name="oldValue">The old value.</param>
        /// <param name="newValue">The new value.</param>
        private void OnRowCountChanged(int oldValue, int newValue)
        {
            InvalidateMeasure();
        }

        #endregion Methods
    }
}