﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SLMedia.Core;
using SLMedia.PlaylistProvider.MSNVideo;

namespace SLExtensions.Showcase
{
    public partial class PagePlayerVideo : UserControl
    {


        #region Constructors

        public PagePlayerVideo()
        {
            InitializeComponent();
            Controller = Resources["controller"] as VideoController;
            this.Loaded += new RoutedEventHandler(VideoPlayer_Loaded);

            MSNVideoProvider msnProvider = new MSNVideoProvider();
            Uri uri = new Uri("http://edge1.catalog.video.msn.com/videoByTag.aspx?tag=frfr_cinetv&ns=MSNVideo_Top_Cat&mk=fr-fr&sf=ActiveStartDate&sd=-1&vs=0&ind=&ps=&rct=&ff=99");
            msnProvider.Source = uri;
            Controller.PlaylistSource = msnProvider;
        }

        void VideoPlayer_Loaded(object sender, RoutedEventArgs e)
        {
            descriptionDesignMargin = gridDescription.Margin;
        }

        #endregion Constructors

        #region Properties

        public VideoController Controller
        {
            get;
            private set;
        }

        #endregion Properties

        #region Methods

        private void Image_ImageFailed(object sender, ExceptionRoutedEventArgs e)
        {
        }

        private void media_MediaFailed(object sender, ExceptionRoutedEventArgs e)
        {
        }

        #endregion Methods

        

        protected override Size ArrangeOverride(Size finalSize)
        {
            Size size = base.ArrangeOverride(finalSize);
            GridClip.RadiusX = border.CornerRadius.TopLeft;
            GridClip.RadiusY = border.CornerRadius.TopLeft;
            GridClip.Rect = new Rect(0, 0, grid.ActualWidth, grid.ActualHeight);
            return size;

        }

        private Thickness descriptionDesignMargin;
        void gridDescription_MouseEnter(object sender, MouseEventArgs e)
        {
            Storyboard sb = new Storyboard();            
            DoubleAnimation anim = new DoubleAnimation();
            sb.Children.Add(anim);
            Storyboard.SetTarget(anim, descriptionMarginWrapper);
            Storyboard.SetTargetProperty(anim, new PropertyPath("(MarginWrapper.MarginTop)"));
            anim.To = Math.Min(descriptionDesignMargin.Top, (descriptionDesignMargin.Top - description.ActualHeight));
            anim.Duration = new Duration(TimeSpan.FromMilliseconds(200));
            sb.Begin();
        }

        void gridDescription_MouseLeave(object sender, MouseEventArgs e)
        {
            Storyboard sb = new Storyboard();
            DoubleAnimation anim = new DoubleAnimation();
            sb.Children.Add(anim);
            Storyboard.SetTarget(anim, descriptionMarginWrapper);
            Storyboard.SetTargetProperty(anim, new PropertyPath("(MarginWrapper.MarginTop)"));
            anim.To = descriptionDesignMargin.Top;
            anim.Duration = new Duration(TimeSpan.FromMilliseconds(200));
            sb.Begin();
        }

    }
}
