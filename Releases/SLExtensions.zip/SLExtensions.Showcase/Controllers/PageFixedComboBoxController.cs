﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SLExtensions.Collections.ObjectModel;
using SLExtensions.Input;

namespace SLExtensions.Showcase.Controllers
{
    public class PageFixedComboBoxController : NotifyingObject
    {
        private readonly ObservableCollection<string> _itemsSource = new ObservableCollection<string>();
        public ObservableCollection<string> ItemsSource { get { return _itemsSource; } }

        private string _addItem;
        public string AddItem
        {
            get { return _addItem; }
            set
            {
                if (_addItem != value)
                {
                    _addItem = value;
                    OnPropertyChanged(AddItemPropertyName);
                }
            }
        }

        public const string AddItemPropertyName = "AddItem";

        private Command _addItemCommand;

       


        public PageFixedComboBoxController()
        {
            AddItem = string.Format("AddItem_{0}", GetHashCode());
            _addItemCommand = new Command(AddItem);
            _addItemCommand.Executed += new EventHandler<ExecutedEventArgs>(_addItemCommand_Executed);
          
        }

    

        void _addItemCommand_Executed(object sender, ExecutedEventArgs e)
        {
            _itemsSource.Add(string.Format("Item {0}", _itemsSource.Count));
        }

    }
}
