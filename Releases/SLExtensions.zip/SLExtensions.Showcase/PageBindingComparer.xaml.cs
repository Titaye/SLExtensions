﻿namespace SLExtensions.Showcase
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Net;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Documents;
    using System.Windows.Input;
    using System.Windows.Media;
    using System.Windows.Media.Animation;
    using System.Windows.Shapes;
    using System.ComponentModel;
    using System.Collections;

    public partial class PageBindingComparer : UserControl
    {
        #region Constructors

        public PageBindingComparer()
        {
            InitializeComponent();
             
        }

        #endregion Constructors

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (((FrameworkElement)sender).DataContext != null)
            {
                ((ImageObj)((FrameworkElement)sender).DataContext).Titre = ((TextBox)sender).Text;
            }
        }

        private void TextBoxId_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (((FrameworkElement)sender).DataContext != null)
            {
                try
                {
                    ((ImageObj)((FrameworkElement)sender).DataContext).Id = Int32.Parse(((TextBox)sender).Text);
                }
                catch { }
            }
        }
    }

    public class CustomCompare : IComparer
    {
        #region IComparer Members

        public int Compare(object x, object y)
        {
            return ((int)x).CompareTo((int)y);
        }

        #endregion
    }

    public class ImageObj : INotifyPropertyChanged
    {
        private int id;

        public int Id
        {
            get { return id; }
            set
            {
                if (id != value)
                {
                    id = value;
                    OnPropertyChanged("Id");
                }
            }
        }


        private int oldId;

        public int OldId
        {
            get { return oldId; }
            set
            {
                if (oldId != value)
                {
                    oldId = value;
                    OnPropertyChanged("OldId");
                }
            }
        }


        private string titre;
        public string Titre
        {
            get { return titre; }
            set
            {
                if (titre != value)
                {
                    titre = value;
                    OnPropertyChanged("Titre");
                }
            }
        }

        private string oldTitre;

        public string OldTitre
        {
            get { return oldTitre; }
            set
            {
                if (oldTitre != value)
                {
                    oldTitre = value;
                    OnPropertyChanged("OldTitre");
                }
            }
        }
        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
    public class ListImageObj : List<ImageObj>
    { }
}