﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SLExtensions.Collections.ObjectModel;
using SLExtensions.Data;

namespace SLExtensions.Showcase
{
    public partial class PageResourceSelector : UserControl
    {
        public PageResourceSelector()
        {
            InitializeComponent();
            dynTplItemsControl.ItemsSource = _itemsSource;
        }
        private ObservableCollection<object> _itemsSource = new ObservableCollection<object>();

        private void OnAddTypeA(object sender, RoutedEventArgs e)
        {
            _itemsSource.Add(new TypeA());
        }

        private void OnAddTypeB(object sender, RoutedEventArgs e)
        {

            _itemsSource.Add(new TypeB());
        }
    }

    public class TypeA { }
    public class TypeB { }

    public class Person : IProvideResourceKey
    {
        public string FirstName { get; set; }
        public double Age { get; set; }

        #region IProvideResourceKey Members

        public string ResourceKey
        {
            get
            {
                if (Age < 2)
                    return "Baby";
                else if (Age < 10)
                    return "Child";
                else if (Age < 20)
                    return "Teenager";
                else return "Adult";
            }
        }

        #endregion
    }
}
